<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NoSeriCetak extends Model
{

  protected $table = 'no_seri_cetak';

  public $timestamps = false;

}
